SensesMe Light library
=========================

Arduino library for controlling Light Sensor




SensesMe Magnetometer library
=========================

Arduino library for controlling Light Sensor




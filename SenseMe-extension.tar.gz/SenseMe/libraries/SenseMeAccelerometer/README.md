SensesMe Accelerometer library
=========================

Arduino library for controlling Freescale MMA865X accelerometer
 
After downloading, rename folder to 'SenseMeAccelerometer' and install in Arduino Libraries folder. Restart Arduino IDE, then open File->Sketchbook->Library->SenseMeAcceleometer

